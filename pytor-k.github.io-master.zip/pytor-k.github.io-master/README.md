# This is the data for my blog

It is automatically transformed by [Jekyll](http://github.com/pytor-k/jekyll)
into a static site whenever I push this repository to GitHub.


## License

Entire site based off of and on top of the work completed by Mojombo. Original repository and user's accound can be found > http://github.com/mojombo/jekyll 