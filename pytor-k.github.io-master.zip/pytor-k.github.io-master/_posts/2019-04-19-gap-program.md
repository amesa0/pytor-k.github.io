---
layout: post
title: Gap Program and Background
published: true
category: Fitness
---

So I'll take the first post of this blog and spend it on something fitness related. Some background, I weigh  80kg and am 175cm roughly. 2015 was the year I began working out, I was drawn into weightlifting after viewing Ilya Ilyin at the 2014 WWC, his 242kg clean and jerk captivated me and I began olympic weightlifting. I did not have proper programming during this time, however I did manage to go from 20kg squat, 60kg deadlift, 0kg snatch, 20kg clean and jerk to 85kg squat, 100kg deadlift, 60kg snatch, 70kg clean and jerk at that gym. I could have done more with proper programming aimed towards younger, skinny athletes; that being more volume whether it be 10, 8, 6reps  rather than sets of 3, 2, or 1rep. Regardless That's what it was. I went from 60kg to 70kg in 2 years but it was not what I was looking for and so I left those gyms. 

I then started working out on my own doing 5x5 and focusing on upper body more, which was non-existent in olympic weightlifting training. I finished off with 105x5 squat, 70x5 bench, 140x3 deadlift, and 100kg clean. I took a break in 2017-2018 and began once again Dec 2018. I started again with a surprisingly maintained 100x5 squat, 70kgx5 bench, 110kg Deadlift, 45kgx5 OHP. Now roughtly 4 months later I have a 155kgx1 squat, 110kgx1 bench, 160kgx2 deadlift. Not great but not awful. 

The last program I did was Candito 6wk program, I enjoyed that, I don't think I have enough knowledge to do a program overview but I did gain like 5-10kg on every lift. One think I didn't like was the lack of volume which I am changing in my next program, the GZCL J&T2.0. I am beginning J&T2.0 on May 6th with a bunch of users on reddit in what they call an "Program Party" where many people begin a program at the same time, I think this would be pretty cool. 

I have 2 more weeks if I am not mistaken and in the mean time I am starting the first 2 weeks of the J&T2.0 in preparation , and since I want to acclimated and subject myself to the awful volume to come. For example: Day 1 begins with 10rm squat into 3+x6reps at a lower weight, then 4x10reps of defecit deadlift, then 3x20reps for the following: Close Stance Squat, Overhand Barbell Row, Underhand Barbell Row, Romanian Deadlift, Goblet Squat, Barbell Curl. Yikes. I did the first week, somehow but week 2 didn't end up to well because I felt fried and so I took 5 days off. However yesterday I finally took up the barbell again, and today as well. I will begin again next week and do the 10's week again, then 8's the following week, then begin the real program on the following week. 

That's enough for the first blog post I think. My goals for this next program, and the next 12 weeks is not only to get stronger, if anything that is a by product, my primary goal is to gain muscle mass. I hope to be at least 90-95kg, and add 10-20kg to each lift, especially the deadlift (I hope for 200kg maybe, I think it is possible)
