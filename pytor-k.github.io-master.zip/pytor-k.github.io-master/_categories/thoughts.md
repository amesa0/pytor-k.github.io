---
category: Thoughts
---
Contents: Things I think about daily, things I have learned, past and present goals and aspirations, and maybe some more.
