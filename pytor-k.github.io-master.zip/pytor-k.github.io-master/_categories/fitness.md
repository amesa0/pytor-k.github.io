---
category: Fitness
---
Contents: I am hoping to share my progress as I workout and become a healthier version of myself.
