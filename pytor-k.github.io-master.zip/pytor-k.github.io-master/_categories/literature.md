---
category: Literature
---
Contents: I'd like to read more, and I'd like to write more. Hopefully in this category there will be lots of reviews and thoughts on many books.
