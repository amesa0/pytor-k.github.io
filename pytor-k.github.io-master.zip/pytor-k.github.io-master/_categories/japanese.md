---
category: Japanese
published: true
---
Contents: 
	A category full of my progress learning Japanese. Why Japanese?: A bit of boredom and a bit of curiosity.

Notes for studying: 
	Read the textbook until you understand the concepts, do all the workbook pages for the lesson, do not neglect learning the vocab and kanji.