---
category: Manga
---
Contents: Reading manga is a passion, I'd like to share some of my thoughts on that which I read.
